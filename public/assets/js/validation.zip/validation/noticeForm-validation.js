
  /* noticeForm validation */
  $(function () {
    // validate the comment form when it is submitted
	   
    $("#noticeForm").validate({
      rules: {
        title: {
          required: true,
          // minlength: 3
        },
        description: {
            // minlength: 3
        },
        notice_file: {
            required: true,
            extension: "pdf|jpg|png|jpeg"
          },

      },
      messages: {
        
        name: {
          required: "Please enter Notice Title.",
          // minlength: "Your Batch Category Name must consist of at least 3 characters."
        },
        notice_file: {
            required: "Select either an image or a pdf as notice attachment.",
            extension: "Notice Attachment has to be either pdf, jpeg, jpg or png file."
        }
      },
      errorPlacement: function (label, element) {
        label.addClass('mt-2 text-danger');
        label.insertAfter(element);
      },
      highlight: function (element, errorClass) {
        $(element).parent().addClass('has-danger')
        $(element).addClass('form-control-danger')
      }
    });
    
  });

/* noticeForm validation */