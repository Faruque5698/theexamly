$(document).ready(function () {

    jQuery.validator.addMethod("phonenu", function (value, element) {
        if (/^(?:\+?88|0088)?0[1-9]\d{9}$/g.test(value)) {
          console.log("here");
          return true;
        } else {
          console.log("not here");
            return false;
        };
    }, "Invalid phone number");

    $.validator.addMethod('size', function(value, element) {
      if(element.files.length == 0){
          return true;
      }
      if(element.files[0].size <= 2097152){
          return true;
      }else{
          return false;
      }
    },'Image size has to be less than 2 MB');  
});


  /* frontedAdmitForm validation */
  $(function () {
    // validate the comment form when it is submitted
	   
    $("#frontedAdmitForm").validate({
      rules: {
        name: {
          required: true
        },
		    phone: {
		      required: true,
          phonenu: true
        },
        email: {
          required: true,
          email: true
        },
        course_name: {
          required: true
        },
        batch_name: {
          required: true
        },
      },
      messages: {
        
        name: {
          required: "Please enter Student Name."
        },
		    phone: {
		      required:  "Please enter a mobile number.",
		      phonenu:  "Please enter a valid mobile number.",
		    },
        email: {
          required:  "Please enter a email address.",
          email: "Please enter a valid email address."
        },
        course_name: {
          required: "Please select Course."
        },
        batch_name: {
          required: "Please select Batch."
        },
      },
      errorPlacement: function (label, element) {
        label.addClass('mt-2 text-danger');
        label.insertAfter(element);
      },
      highlight: function (element, errorClass) {
        $(element).parent().addClass('has-danger')
        $(element).addClass('form-control-danger')
      }
    });
    
  });

/* frontedAdmitForm validation */