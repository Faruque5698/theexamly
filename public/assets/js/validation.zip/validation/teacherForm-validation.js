$(document).ready(function () {

    jQuery.validator.addMethod("phonenu", function (value, element) {
            if (/^(?:\+?88|0088)?01[15-9]\d{8}$/g.test(value)) {

            return true;
        } else {
            return false;
        };
    }, "Invalid phone number");

    $.validator.addMethod('size', function(value, element) {
      if(element.files.length == 0){
          return true;
      }
      if(element.files[0].size <= 2097152){
          return true;
      }else{
          return false;
      }
    },'Image size has to be less than 2 MB');  
});


  /* teacherForm validation */
  $(function () {
    // validate the comment form when it is submitted
	   
    $("#teacherForm").validate({
      rules: {
        name: {
          required: true,
          minlength: 3
        },
		    email: {
          required: true,
          email: true
        },
		    phone: {
		      required: true,
          phonenu: true
        },
        password: {
          required: true,
          minlength: 6
        },
        image: {
          extension: "jpg|png|jpeg",
          size: true,
        },
      },
      messages: {
        
        name: {
          required: "Please enter Teacher Name.",
          minlength: "Your Teacher Name must consist of at least 3 characters."
        },
		    email: {
		      required:  "Please enter a email address.",
		      email: "Please enter a valid email address."
		    },
		    phone: {
		      required:  "Please enter a mobile number.",
		      phonenu:  "Please enter a valid mobile number.",
		    },
        password: {
          required: "Please provide a password",
          minlength: "Your password must be at least 8 characters long"
        },
        image: {
          extension: "Please select an image with an extension of either .jpg .png or .jpeg",
        }
      },
      errorPlacement: function (label, element) {
        label.addClass('mt-2 text-danger');
        label.insertAfter(element);
      },
      highlight: function (element, errorClass) {
        $(element).parent().addClass('has-danger')
        $(element).addClass('form-control-danger')
      }
    });
    
  });

/* teacherForm validation */