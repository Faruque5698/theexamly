  /* passwordForm validation */
  $(function () {
    // validate the comment form when it is submitted

    $("#passwordForm").validate({
      rules: {
        oldpassword: {
          required: true,
          minlength: 8
        },
    password: {
          required: true,
          minlength: 8
        },
    password_confirmation: {
        required: true,
        minlength: 8
        },
      },  
      messages: {
        
    oldpassword: {
          required: "Please enter old password.",
          minlength: "Your old password must be at least 8 characters long."
        },
    password: {
      required:  "Please enter new password.",
      minlength: "Your new password must be at least 8 characters long."
    },
    password_confirmation: {
      required:  "Please enter confirm password.",
      minlength: "YYour confirm password must be at least 8 characters long."
    },
          
      },
      errorPlacement: function (label, element) {
        label.addClass('mt-2 text-danger');
        label.insertAfter(element);
      },
      highlight: function (element, errorClass) {
        $(element).parent().addClass('has-danger')
        $(element).addClass('form-control-danger')
      }
    });
    
  });

/* passwordForm validation */