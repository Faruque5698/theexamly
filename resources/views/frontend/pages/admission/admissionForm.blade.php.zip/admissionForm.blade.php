@extends('frontend.layout.master')

@push('plugin-styles')
    {!! Html::style('public/assets/plugins/jquery-toast-plugin/jquery.toast.min.css') !!}
    {!! Html::style('public/assets/plugins/choices/public/assets/styles/choices.min.css') !!}
    {!! Html::style('public/assets/plugins/icheck/skins/all.css') !!}
    {!! Html::style('public/css/loader.css') !!}
@endpush

@section('content')

    <main>
      <!-- page title -->
      <section class="page_title">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div
                class="page_title_container d-flex flex-column align-items-center justify-content-center"
              >
                <div class="page_title_heading">
                  <h2 class="header mb-0">রেজিস্ট্রেশন</h2>
                </div>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item breadcrumb_item">
                      <a href="{{ route('frontend.index') }}">হোম</a>
                    </li>
                    <li class="breadcrumb-item breadcrumb_item active">
                      <a href="{{ route('frontend.showAdmissionForm') }}">রেজিস্ট্রেশন</a>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- end page title -->
      <!-- register form -->
      <section class="register my-5">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-12 col-lg-6">
              <div class="register_box p-2 p-lg-5">
                <!-- Title Box -->
                <div class="heading text-center mb-5">
                  <h2 class="header">রেজিস্ট্রেশন</h2>
                  <div class="paragraph">
                    এখানে সকল তথ্য ইংলিশ এ দিয়ে রেজিস্ট্রেশন সম্পূর্ণ করুন ।
                  </div>
                </div>

                <!-- Login Form -->
                <div class="register_form">
                  <form class="cmxform" id="frontedAdmitForm" method="post" action="{{ route('admission.form.confirm') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                      <!-- Form Group -->
                      <div class="form-group col-12">
                        <label
                          >নামের প্রথম অংশ (নামের শেষ অংশ বাদে সকল অংশ )</label
                        > <span class="requiredStar" style="color: red"> * </span>
                        <input name="first_name" id="first_name"
                          class="form-control form_control"
                          type="text"
                          placeholder="e.g. Md. Abdullah"
                        />
                      </div>
                      <div class="form-group col-12">
                        <label>নামের শেষ অংশ </label> <span class="requiredStar" style="color: red"> * </span>
                        <input name="last_name" id="last_name"
                          class="form-control form_control"
                          type="text"
                          placeholder="e.g. Mamun"
                        />
                      </div>

                      <!-- Form Group -->
                      <div class="form-group col-12">
                        <label>ইমেইল</label> <span class="requiredStar" style="color: red"> * </span><span>( জিমেইল আবশ্যক  )</span>
                        <input name="email" id="email"
                          class="form-control form_control"
                          type="email"
                          placeholder="e.g. name@gmail.com"
                        />
                      </div>

                      <!-- Form Group -->
                      <div class="form-group col-12">
                        <label>মোবাইল নাম্বার </label> <span class="requiredStar" style="color: red"> * </span>
                        <input 
                          class="form-control form_control"
                          type="text"
                          name="phone"
                          id="phone"
                          placeholder="e.g. 01900011100"
                        />
                      </div>
                      <?php 
                        use App\Models\Backend\Course; 
                        use App\Models\Backend\CourseCategory; 
                        use App\Models\Backend\Subject; 
                        $courses = Course::where('full_name', $slug)->pluck('id')->first();
                        $coursesCategoryId = Subject::where('group_id', $courses)->pluck('exam_category')->first();
                        $coursesCategoryName = CourseCategory::where('id', $coursesCategoryId)->pluck('name')->first();
                      ?>
                      <div class="form-group col-12">
                        <label>পরীক্ষার ধরণ</label> <span class="requiredStar" style="color: red"> * </span>
                        <select class="form-control form_control_select" name="exam_type" id="exam_type" required>
                          <option value="">Select one..</option>
                          @foreach($examCategory as $key=>$category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                          @endforeach
                        </select>
                      </div>
                      <div class="form-group col-12">
                        <label>পরীক্ষা</label> <span class="requiredStar" style="color: red"> * </span>
                        <select class="form-control form_control_select" name="exam" id="exam" required>
                          <option value="">Select one..</option>
                        </select>
                      </div>
                      <div class="ajax_loader">
                        <img src="{{ url('public/assets/images/loading.gif') }}" class="img-responsive" />
                      </div>
                      <div class="form-group col-12">
                        <label>বিষয়</label> <span class="requiredStar" style="color: red"> * </span>
                        <div
                          class="accordion exam_dropdown"
                          id="accordionExample"
                        >
                          <div class="card">
                            <div
                              class="card-header card_header"
                              id="headingOne"
                            >
                              <h2 class="mb-0">
                                <button
                                  class="btn btn-link btn-block text-left"
                                  type="button"
                                  data-toggle="collapse"
                                  data-target="#collapseOne"
                                  aria-expanded="true"
                                  aria-controls="collapseOne"
                                >
                                  <div class="form-group form_group form-check">
                                    <input
                                      type="checkbox" id="checkall" name="subject"
                                      class="form-check-input form_check_input"
                                    />
                                    <label
                                      class="form-check-label form_check_label align-bottom"
                                      >All</label
                                    >
                                  </div>
                                </button>
                              </h2>
                            </div>

                            <div
                              id="collapseOne"
                              class="collapse"
                              aria-labelledby="headingOne"
                              data-parent="#accordionExample"
                            >
                              <div class="card-body card_body">
                                <ul class="list-group" id="a" style="cursor:not-allowed;">
                                  {{-- <li
                                    class="list-group-item border-0 bg-transparent"
                                  >
                                    <div
                                      class="form-group form_group form-check"
                                    >
                                      <input
                                        type="checkbox"
                                        class="form-check-input form_check_input"
                                      />
                                      <label
                                        class="form-check-label form_check_label"
                                        >Bangla</label
                                      >
                                    </div>
                                  </li> --}}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="form-group col-12 text-center" id="course_fees">
                        <p class="exam_amount mb-0">সর্বমোট : <input id="course_fee" class="" type="text" name="course_fee" value="0" readonly style="width: 50px"> টাকা</p>
                      </div>
                        
                      <div class="form-group col-12">
                        <label >পাসওয়ার্ড</label> <span class="requiredStar" style="color: red"> * </span>
                        <div class="input-group">
                          <input  class="form-control form_control" name="password" id="password" type="password"
                          placeholder="* * * * * * * *"aria-label="Recipient's username" aria-describedby="basic-addon2">
                          <div class="input-group-append ">
                            <span class="input-group-text border-0" onclick="password_show_hide();">
                              <i class="fas fa-eye-slash" id="show_eye"></i>
                              <i class="fas fa-eye d-none" id="hide_eye"></i>
                            </span>
                          </div>
                          <small class="form-text text_muted text-justify">পাসওয়ার্ডটিতে অবশ্যই বড় হাতের অক্ষর, ছোট হাতের অক্ষর, সংখ্যা এবং একটি স্পেশাল ক্যারেক্টার
                          (!,@,#,$,%,^,&,*) সহ কমপক্ষে ৮ টি অক্ষর থাকতে হবে।</small>
                        </div>
                      </div>

                      <div class="form-group col-12">
                        <label>কনফার্ম পাসওয়ার্ড</label> <span class="requiredStar" style="color: red"> * </span>

                        <div class="input-group">
                          <input  class="form-control form_control" name="confirm_password" id="confirm_password" type="password"
                          placeholder="* * * * * * * *"aria-label="Recipient's username" aria-describedby="basic-addon2">
                          <div class="input-group-append ">
                            <span class="input-group-text border-0" onclick="password_show_hide2();">
                              <i class="fas fa-eye-slash" id="show_eye2"></i>
                              <i class="fas fa-eye d-none" id="hide_eye2"></i>
                            </span>
                          </div>
                          {{-- <small class="form-text text_muted text-justify">পাসওয়ার্ডটিতে অবশ্যই বড় হাতের অক্ষর, ছোট হাতের অক্ষর, সংখ্যা এবং একটি স্পেশাল ক্যারেক্টার
                          (!,@,#,$,%,^,&,*) সহ কমপক্ষে ৮ টি অক্ষর থাকতে হবে।</small> --}}
                        </div>
                      </div>

                      <!-- term -->
                      <div class="form-group col-12">
                        <div class="form-group form_group form-check">
                          <input id="checkbox" name="checkbox"
                            type="checkbox"
                            class="form-check-input form_check_input" required 
                          />
                          <label class="form-check-label form_check_label"
                            >আমি <a href="{{ route('privacyPolicy') }}">গোপনীয়তার নীতিমালা</a>, <a href="{{ route('termsAndConditions') }}">ব্যবহারের শর্তাবলীর</a> সাথে একমত পোষণ করছি ।
                          </label> 
                        </div>
                      </div>

                      <div class="form-group col-12 text-center">
                        <button type="submit" class="btn_primary" id="submit_button">
                          <span>সাইন আপ </span>
                        </button>
                      </div>

                      <div class="form-group col-12 text-center">
                        <div class="users">
                          আগেই অ্যাকাউন্ট খুলেছিলেন ? তাহলে
                          <a class="secondary_color" href="{{ route('user.login') }}">
                            লগ-ইন করুন
                          </a>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  {{-- @endpush--}}
@endsection  

@push('plugin-scripts')
    <!-- js -->
    <script src="{{ asset('public/assets/plugins/jquery-validation/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('public/assets/plugins/jquery-toast-plugin/jquery.toast.min.js') }}"></script>
    <script src="{{ asset('public/assets/plugins/choices/public/assets/scripts/choices.min.js') }}"></script>
    <script src="{{ asset('public/assets/plugins/icheck/icheck.min.js') }}"></script>
@endpush
@push('custom-scripts')    
    <!-- custom js -->
    <script src="{{ asset('public/assets/js/validation/frontedAdmitForm-validation.js') }}"></script>
    <script src="{{ asset('public/assets/js/iCheck.js') }}"></script>
    <script src="{{ asset('public/assets/plugins/Bootstrap-4-Multi-Select/dist/js/BsMultiSelect.js') }}"></script>
    <script src="{{ asset('public/assets/js/toastDemo.js') }}"></script>
    
    <script type="text/javascript">
      $(document).ready(function () {
          @if (session('success'))
          showSuccessToast('{{ session("success") }}');
          @elseif(session('danger'))
          showDangerToast('{{ session("danger") }}');
          @elseif(session('warning'))
          showWarningToast('{{ session("warning") }}');
          @endif
      });
  </script>

    {{-- select2 function use --}}
    {{-- <script type="text/javascript">
        $(document).ready(function() {
            $('#district').select2();
        });
        $(document).ready(function() {
            $('#thana').select2();
        });
    </script> --}}

    <!-- dropdown.blade.php -->
    <script type="text/javascript">
        jQuery(document).ready(function ()
        {
          
          jQuery('select[name="exam_type"]').on('change',function(){
          var exam_type = jQuery(this).val();

          if(exam_type){
            jQuery.ajax({
              url : 'form/course/' +exam_type,
              type : "GET",
              dataType : "json",
               beforeSend: function(jqXHR,settings)
              {
                $('.ajax_loader').css("visibility", "visible");
                 // console.log(settings.url);
              },
              success:function(data)
              {
                // console.log(data);
                jQuery('select[name="exam"]').empty();
                $('select[name="exam"]').append('<option value="">Select one..</option>');
                jQuery.each(data, function(key,value){
                    $('select[name="exam"]').append('<option value="'+ key +'">'+ value +'</option>');
                });
              },
              complete: function()
              {
                $('.ajax_loader').css("visibility", "hidden");
              },
            });
          }
        });
       });   
    </script> 
    <script type="text/javascript">
        jQuery(document).ready(function ()
        {
            jQuery('select[name="exam"]').on('change',function(){

                var countryID = jQuery(this).val();
                var courseCategory = $("#exam_type").val();
                 // console.log(courseCategory);
                if(countryID)
                   {
                      jQuery.ajax({
                         url : 'form/subject/' +courseCategory+'/'+countryID ,
                         type : "GET",
                         dataType : "json",
                         beforeSend: function(jqXHR,settings)
                        {
                          $('.ajax_loader').css("visibility", "visible");
                        //   console.log(settings.url);
                        },
                         success:function(data)
                         {
                        //   console.log(data);
                          if(data.length == 0) {
                                  alert('No available subject');
                                  return;
                            }
                          $(document).ready(function(){
                             var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
                             removeItemButton: true,
                             maxItemCount:15,
                             searchResultLimit:12,
                             renderChoiceLimit:15
                             });

                             $("div").focusout(function(){
                                 $(this).css("background-color", "#FFFFFF");
                             });

                             });

                             $("#frontedAdmitForm").submit(function(e) {
                                 var contents = $('#choices-multiple-remove-button').val();

                                 if(contents.length === 0){

                                 }
                             });
                            $('#a').empty();
                            if(courseCategory=='2' || courseCategory=='7'){
                              $.each(data , function(index, data) { 
                              for (let index = 0; index < data.length; index++) {
                               
                                $('#a').append('<li class="list-group-item border-0 bg-transparent"><div class="form-group form_group form-check"><input class="form-check-input form_check_input checkboxes" type="checkbox" checked disabled style="cursor:not-allowed" id="subject_id" name="subject_id[]" value="'+data[index].id+'"> '+data[index].name+'<input class="form-check-input form_check_input checkboxes" type="hidden" checked  style="cursor:not-allowed" id="subject_id" name="subject_id[]" value="'+data[index].id+'"><label class="form-check-label form_check_label"></label></div></li>'); 
                              }
                            }); 
                              $('#checkall').prop('checked', true);
                              $('#checkall').prop('disabled', true);
                              document.getElementById('a').style.pointerEvents = 'none';
                              totalAmount(countryID);
                            }else{
                            $.each(data , function(index, data) { 
                              for (let index = 0; index < data.length; index++) {
                               
                                $('#a').append('<li class="list-group-item border-0 bg-transparent"><div class="form-group form_group form-check"><input class="form-check-input form_check_input checkboxes" type="checkbox" id="subject_id" name="subject_id[]" value="'+data[index].id+'"> '+data[index].name+'<label class="form-check-label form_check_label"></label></div></li>'); 
                              }
                            });
                            $('#checkall').prop('checked', false);
                            $('#checkall').prop('disabled', false);
                            $("#course_fees").load(location.href + " #course_fees");
                          }
                         },
                         complete: function()
                        {
                          $('.ajax_loader').css("visibility", "hidden");
                        },
                      });
                    }
                else{
                      $('#a').empty();
                   }
            });
        });
    </script>
    <script type="text/javascript">
        jQuery(document).ready(function ()
        { 
            jQuery("#a").click(function(){
                var favorite = [];
            $.each($("input[name='subject_id[]']:checked"), function(){            
                favorite.push($(this).val());
                // console.log(favorite);
            });
                var sum =0;
                $.each(favorite , function(index, val) { 
                //   console.log(index, val);
                if(favorite)
                   {
                      jQuery.ajax({
                         url : 'form/fee/' +val,
                         type : "GET",
                         dataType : "json",
                         beforeSend: function(jqXHR,settings)
                        {
                          $('.ajax_loader').css("visibility", "visible");
                        //   console.log(settings.url);
                        },
                         success:function(data)
                         {
                            jQuery('#course_fee').empty();
                            jQuery.each(data, function(key,value){
                              sum = value+sum;
                              // console.log(sum);
                                $('#course_fee').val(sum);
                            });
                         },
                         complete: function()
                         {
                           $('.ajax_loader').css("visibility", "hidden");
                         },
                      });
                    }
                else{
                      $('#course_fee').empty();
                   } 
               });
            });
        });
    </script>

    {{-- if checkall button show total amount over all subject --}}
    <script type="text/javascript">
        $('#checkall').click(function() {
          
          var course = $("#exam").val();
          if(this.checked){
              jQuery.ajax({
                  url : 'form/totalFee/' +course,
                  type : "GET",
                  dataType : "json",
                  beforeSend: function(jqXHR,settings)
                {
                  $('.ajax_loader').css("visibility", "visible");
                //   console.log(settings.url);
                },
                  success:function(data)
                  {
                //   console.log(data);
                    jQuery('#course_fee').empty();
                        $('#course_fee').val(data);
                  },
                  complete: function()
                  {
                    $('.ajax_loader').css("visibility", "hidden");
                  },
              });
            }
        else{
              $('#course_fee').empty();
            } 
        });
    </script>

    <script type="text/javascript">
      function totalAmount(countryID) {
         var course = countryID;
         // console.log(course);
          if(course){
            
              jQuery.ajax({
                  url : 'form/totalFee/' +course,
                  type : "GET",
                  dataType : "json",
                  beforeSend: function(jqXHR,settings)
                {
                  $('.ajax_loader').css("visibility", "visible");
                //   console.log(settings.url);
                },
                  success:function(data)
                  {
                  // console.log(data);
                    jQuery('#course_fee').empty();
                        $('#course_fee').val(data);
                  },
                  complete: function()
                  {
                    $('.ajax_loader').css("visibility", "hidden");
                  },
              });
            }
        else{
              $('#course_fee').empty();
            }
      }
    </script> 

    {{-- check all button function --}}
    <script type="text/javascript">
      $("#checkall").click(function (){
          if ($("#checkall").is(':checked')){
             $(".checkboxes").each(function (){
                $(this).prop("checked", true);
                });
             }else{
                $(".checkboxes").each(function (){
                     $(this).prop("checked", false);
                });
             }
      });
      // function toggle(source) {
      //     var checkboxes = document.querySelectorAll('input[type="checkbox"]');
      //     for (var i = 0; i < checkboxes.length; i++) {
      //         if (checkboxes[i] != source)
      //             checkboxes[i].checked = source.checked;
      //     }
      // }
    </script>

    {{-- terms and condition check also enable submit button function--}}
    <script>
      $('#checkbox').change(function() {
        if(this.checked) {
          $("#submit_button").removeAttr('disabled');
        }else{
          $("#submit_button").prop("disabled", true);
        }
      });
    </script>

    {{-- hash password view function --}}
    <script type="text/javascript">
      function myFunction() {
        var x = document.getElementById("password");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
    </script> 
    
        <script type="text/javascript">
      function password_show_hide() {
        var x = document.getElementById("password");
        var show_eye = document.getElementById("show_eye");
        var hide_eye = document.getElementById("hide_eye");
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
          x.type = "text";
          show_eye.style.display = "none";
          hide_eye.style.display = "block";
        } else {
          x.type = "password";
          show_eye.style.display = "block";
          hide_eye.style.display = "none";
        }
      }
      function password_show_hide2() {
        var x = document.getElementById("confirm_password");
        var show_eye2 = document.getElementById("show_eye2");
        var hide_eye2 = document.getElementById("hide_eye2");
        hide_eye2.classList.remove("d-none");
        if (x.type === "password") {
          x.type = "text";
          show_eye2.style.display = "none";
          hide_eye2.style.display = "block";
        } else {
          x.type = "password";
          show_eye2.style.display = "block";
          hide_eye2.style.display = "none";
        }
      }
    </script>
    {{-- <script type="text/javascript">
      $('#confirm_password').click(function(){
          if('password' == $('#confirm_password').attr('type')){
               $('#confirm_password').prop('type', 'text');
          }else{
               $('#confirm_password').prop('type', 'password');
          }
      });
    </script> --}}
@endpush